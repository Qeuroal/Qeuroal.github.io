import os
import sys
sys.path.append("..") # add path: os.path.abspath("../")
print(sys.path)
from suboptimum_way_src.subdir_1 import file_1_1
