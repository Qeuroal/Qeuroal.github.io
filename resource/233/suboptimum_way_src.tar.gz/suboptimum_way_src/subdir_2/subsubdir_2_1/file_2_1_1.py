def main():
    print(__file__)
