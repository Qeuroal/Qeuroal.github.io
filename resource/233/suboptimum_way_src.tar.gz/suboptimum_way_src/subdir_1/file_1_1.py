# 同模块调用
from .subsubdir_1_1 import file_1_1_1

# 跨模块调用
from ..subdir_2 import file_2_1

def main():
    print(__file__)
