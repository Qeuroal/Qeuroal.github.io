from subdir_2.subsubdir_2_1 import file_2_1_2

def main():
    print(__file__)
