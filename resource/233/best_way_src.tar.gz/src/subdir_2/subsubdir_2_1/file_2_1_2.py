def main():
    print(__file__)
main()
