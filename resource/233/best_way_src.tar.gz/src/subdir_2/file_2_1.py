from . import file_2_2
from .subsubdir_2_1 import file_2_1_1, file_2_1_2

def main():
  print(__file__)
